---
name: kocskin-post-writer
description: 為 KOCSKIN 克麗詩黛品牌官方帳號撰寫 Facebook／Instagram 貼文（預設兩版），含品牌語氣、內容類型範本、自動配圖候選與獨立合規審查。寫 FB 貼文、IG 貼文、粉絲頁貼文時觸發。Threads／脆請改用 kocskin-threads-writer。
---

> **⚠️ ChatGPT 版平台對照（2026-09-15 打包；正本仍在 Claude 帳號與 ~/kocskin-knowledge/skills）**
> 本 skill 原為 Claude 環境撰寫，規則與紅線全部照舊，只有「工具怎麼叫」不同：
> - 文中的 `mcp__…__notion-*`、`notion-query-data-sources`（SQL）、`notion-search`、`notion-fetch` → 一律改用 **ChatGPT 已連接的 Notion connector**。ChatGPT 的 Notion 連接器**沒有 SQL 模式**，「多條件篩選／全表計數」改用 connector 的搜尋＋逐頁讀取，數量以實際讀到的為準，不得推估。
> - 「派 fresh subagent 審查」→ ChatGPT 無 subagent：產出後**開新對話**（或至少新一輪、明講「只審不改」）跑 `kocskin-compliance-check`，逐關結論貼回。
> - 「寫入 Notion」「呼叫 Buffer」「Cloudinary 上傳」→ 沒有對應 connector 就**不寫、不排程、不上傳**，改輸出純文字＋操作清單給 Welson 手動執行。憲章 R4／發佈關卡在任何平台都不放寬。
> - `SendUserFile`／`device_commit_files`／`propose_skills` → ChatGPT 對應為直接輸出下載檔案；本機路徑（`~/Desktop/…`）改為請 Welson 上傳檔案到對話。
> - **Notion 連不上或 connector 未授權 → 依 R1 明講「未連 V2、無法核對合規卡」，不產出商品文案。**
> - 「正式模式寫入 📅 社群貼文管理 DB」與 Cloudinary 動態裁切網址規則照舊；若 Notion connector 無寫入權限，輸出「Notion 寫入清單（欄位＝值）」給 Welson 手動建列。快線 `create_post shareNow` 在 ChatGPT 無 Buffer 時不可執行，改為交付文案由 Welson 手動發。

# KOCSKIN 社群貼文生成器（FB / IG）

為 KOCSKIN 品牌官方帳號的社群貼文把關品質與合規。丟主題或商品，這個 skill 把流程串好。

## 範圍邊界

**這支 skill 只用於 KOCSKIN 品牌官方帳號的 Facebook 與 Instagram。**

不適用：
- **Threads／脆（@koc_skin）→ `kocskin-threads-writer`**
- Welson 個人 FB（短 3–5 行、自嘲、無 hashtag — 風格完全不同）
- 露營瘋／瘋大叔粉絲頁（戶外社群調性，未在此 skill 範圍）
- LP 文案、廣告素材、Email、新聞稿

碰到上列情境，提醒使用者改用對應 skill 或另行處理，不要硬寫。

### FB/IG 與 Threads 是兩條獨立內容線

Welson 2026-07-25 裁定：兩線各自規劃、各自排程、各自配比。**禁止把 FB/IG 文案搬去 Threads，或同一則文同時排兩邊。** 要在 Threads 講同一支商品，必須用 `kocskin-threads-writer` 另寫一版。

（規則全文見專案文件 `claude/發文渠道分流規範.md`。）

## 模式（先確認，再動手）

| 模式 | 行為 |
| --- | --- |
| **草稿（預設）** | 產文 + 跑合規審查；不寫 Notion |
| **正式** | 產文 + 跑合規審查 + 寫入 Notion 📅 社群貼文管理 DB（`04b770fc-b2fa-4185-85e4-b6245777557d`），狀態一律 `待審`、`啟用自動發文` 不勾。**只寫 Notion，排程不碰 Buffer**（見〈發佈關卡・鐵律〉） |
| **快線** | 臨時議題即時發布，不進 Buffer 佇列。見〈唯一例外：快線〉 |
| **研究** | 不產文，只給內容類型建議與資料蒐集；不跑 compliance |

未指定 → 預設草稿。使用者說「正式」「上稿」「寫進 Notion」「同步社群 DB」→ 切正式模式。使用者說「馬上發」「現在就發」「不要排程」→ 快線。

## 發佈關卡・鐵律（最重要，違反＝搶跑）

KOCSKIN 排程貼文的發佈流程是一條**單向管道**，每一關的核准點都在指定位置，AI 不得跳關：

```
AI 寫文＋獨立審查  →  寫入 Notion（狀態＝待審）  →  【Welson 在 Notion 按「核准」＋勾「啟用自動發文」】  →  自動發文引擎掃描  →  引擎寫入 Buffer  →  Buffer 自動發佈
```

- **核准這一關只在 Notion 按**。使用者在對話裡說「OK／定稿／可以發」＝同意這份文案內容，**不等於** Notion 的「核准」，更不是授權你去送 Buffer。
- **排程貼文，AI 不得直接呼叫 Buffer**（`create_post` 等）。送 Buffer 是「自動發文引擎」在 Welson 於 Notion 核准後的**專責動作**。
- 正式模式寫 Notion 時：`文案狀態＝待審`、`啟用自動發文` 留空（`__NO__`）、**不要**填 `Buffer貼文ID`、`發文狀態＝待發`。核准與啟用一律留給 Welson 在 Notion 手動完成。
- 使用者就算明講「幫我排到 X 點自動發」，正確做法仍是：寫成 Notion 待審＋設好 `發文日期`，然後告訴他「請到 Notion 核准＋勾啟用，引擎會自動送 Buffer」。**不是**自己動手排 Buffer。
- 引擎排程：`trig_01DgE6EUokjbzYxWMjeREBnD`「KOCSKIN 自動發文引擎（核可→Buffer）v2」，cron `36 */5 * * *`（**每 5 小時的第 36 分**掃描一次）。送 Buffer 需距發文 ≥30 分鐘，且下一次掃描最長可能要等 5 小時——提醒 Welson **提早半天核准**，不要壓線。

### 唯一例外：快線（臨時議題即時發布）

Welson 2026-07-25 開放：他丟一個臨時想法要「馬上發」時，可走 `create_post` 的 `mode: shareNow` 直接發布，不進 Buffer 佇列。條件全部成立才可執行：

1. 是 Welson 本人在這一輪明確提出的臨時發文需求；
2. 提及商品的話仍**必須查 V2 合規卡**（這關省不掉）；
3. 我先做一次內審並附結論，**Critical 等級問題（醫療效能宣稱、無文號美白、停售品、真實名人虛構引述）必須明確標紅呈報**；
4. **臨時發文由 Welson 自審把關**，最終判斷權在他；
5. **他明確說「發」之後**才執行 `create_post`，AI 不自行按送出。

快線適用純觀點、時事承接、輕量互動。要完整推商品、要配圖排版的貼文不走快線。

## 流程（3 步）

### Step 1：查商品（僅在指定商品時）

若使用者指定具體商品（例：「玫瑰超導安瓶」「青春美妍膠原飲」），**必須呼叫 `kocskin-product-lookup`** 取得：
- 產品名稱、售價、容量規格
- 核心成分、主打賣點
- 適用膚質、目標客群
- **合規備注**（直接決定文案用字邊界，必須完整帶入 Step 2）

若使用者只給「教育型主題」（例：「敏感肌保養知識」「換季膚況」）沒指定商品 → 跳過此步。

**禁止憑記憶寫商品資料。** 記憶會錯，也會過時。

### Step 2：寫文案

選一個內容類型（單篇選擇，不做比例追蹤）：

| 類型 | 適用情境 |
| --- | --- |
| **商品價值型** | 主推單一商品的賣點、成分、適用族群 |
| **教育型** | 保養知識、使用教學、膚質判別 |
| **見證品牌型** | 使用者見證、品牌故事、幕後 |
| **促銷導購型** | 檔期活動、折扣、新品發表 |

四種類型的詳細結構範本見 [references/content-types.md](references/content-types.md)。

依選定平台（FB / IG，**預設兩平台同產**）撰寫，平台差異見 [references/platform-specs.md](references/platform-specs.md)。兩個平台不能一貼二用，第一行、斷行、hashtag 各自有套法。

**字數**（Welson 2026-07-25 裁定，取代舊的「FB/IG 一律 150 字內」合併規格；2026-08-02 Welson 確認以《發文渠道分流規範》為準）：

- **FB：不設字數上限**，依內容需要決定長短（前 3 行仍是決定展開的關鍵）。
  - 目標區間（Welson 2026-08-07）：**小燕第一人稱 400–700 字**、品牌口吻商品文 250–400 字。第一人稱寫太短撐不出人味。
- **IG：150 字內。**

### Step 2.5：執行長第一人稱模式（配圖有小燕入鏡時必用）

Welson 2026-08-07 裁定：**既然選了執行長小燕的照片，內文就要用她的第一視角講，而且要有人味，不要太制式。**

判準只有一個——**配圖裡有沒有小燕**：

- **有她入鏡** → FB 與 IG 兩版都用她的第一人稱「我」，篇幅拉長，寫她的取捨、習慣與偏好。
- **沒有她入鏡**（白底、質地照、成分照、AI實景）→ 維持品牌口吻「我們」。

**圖文人稱必須一致**：沒有人的質地照配「我昨天……」會出戲，小燕手持照配「KOCSKIN 為您帶來」則是白拍了。同一批排程裡兩種人稱並存是正常的。

能寫到什麼程度、去 AI 味的十項自查、對照範例 → [references/ceo-first-person.md](references/ceo-first-person.md)。**寫第一人稱前必讀該檔。**

三條紅線先記著：

1. **不得用她的名義做效果見證**（「我用了兩週就……」）。可以寫「我習慣睡前擦」，不能寫「我擦了之後變成怎樣」。
2. **不得編造具體事件或引述句**。日期、地點、對象、原話，沒有出處就不寫。
3. **每一則第一人稱貼文，Welson 或小燕本人發前確認。** 寫入 Notion 時 `備注說明` 必須註明「第一人稱貼文，待小燕或 Welson 確認語氣與事實後才可核准」。這是 R2 之外的額外一關。

**品牌語氣**：
- ✅ 親切、專業、有溫度（懂成分的閨蜜分享）
- ✅ 具體、可證據化（成分、實驗、見證）
- ❌ 焦慮行銷（「再不用就完了」）
- ❌ 誇大神化（「神級」「逆天」「奇蹟」）
- ❌ 過度口語（「姊妹們快衝」）
- ❌ 過度正式（「本公司隆重推出」）

語氣對照範例見 [references/voice-examples.md](references/voice-examples.md)。

### Step 3：獨立合規審查（分開執行，不等下一輪）

**產出與審查必須由不同的一方做**（憲章 R2）。Welson 2026-07-25 裁定：取消「停一輪」的等待，但**不取消分開審查**。

做法：寫完後在同一輪內**派 fresh subagent** 跑四關，只審不改，回傳逐關結論。也可直接呼叫 `kocskin-compliance-check`。

- **Critical / High** → 修正後再送審一次
- **Medium / Low** → 輸出並附審查摘要，由使用者決定是否微調

審查通過的證據是**逐關結論**，不是一句「已檢查」。

合規檢查涵蓋化粧品／保健食品法規、停售商品、PDRN 線歸屬、簡體字、執行長稱呼、虛構名人引述等。**所有合規規則交給 compliance skill 統一維護**，這支不重複列。

## 輸出格式

純文字、無裝飾分隔線。範本：

```
KOCSKIN｜[主題或商品]｜[類型]

【Facebook】
（正文段落式，長度依內容需要；FB 不設上限）

#hashtag1 #hashtag2 #hashtag3（3–5 個，含 #KOCSKIN）

【Instagram】
（第一行 hook）

（主文 150 字內，斷行較多）

#hashtag1 #hashtag2 ...（3–5 個，含 #KOCSKIN）

——
配圖候選：1. [圖名／類型] 2. [圖名／類型] 3. [圖名／類型] → 請挑一張
合規審查：🟢 通過 ／ 🟡 建議調整 — [逐關結論]
備注：[是否需小燕出鏡／檔期搭配，1–3 點]
```

**正式模式額外動作**：呼叫 Notion API 寫入 📅 社群貼文管理 DB（`04b770fc-b2fa-4185-85e4-b6245777557d`）。每個平台一列，欄位包含：貼文標題、發文平台、主角商品、內容類型、貼文文案、Hashtag、圖片網址、導購連結、發文日期（datetime，用展開鍵 `date:發文日期:start`＋`date:發文日期:is_datetime`）。**狀態欄位固定**：`文案狀態＝待審`、`發文狀態＝待發`、`啟用自動發文＝__NO__`、不填 `Buffer貼文ID`（checkbox 欄位值用字串 `__YES__`／`__NO__`，不是布林）。**寫入前先顯示摘要，等使用者確認後再寫**。寫入失敗則輸出純文字供手動建立。**寫完就結束——不呼叫 Buffer、不改核准狀態**；接著提示 Welson 到 Notion 核准＋勾啟用即可。

## 配圖（自動跳候選 ＋ 依平台切尺寸）

Welson 2026-07-25 裁定：FB/IG **自動從素材圖庫跳候選圖，並依平台自動切換尺寸**。

### Step A：從素材庫查候選

**素材圖庫索引：** `collection://a924b6bd-c492-4328-93ea-3d036229301f`
欄位：圖名／SKU／商品(relation)／商品名／場景／類型／狀態／圖片網址／尺寸／備註

```sql
SELECT "圖名", "SKU", "類型", "場景", "圖片網址"
FROM "collection://a924b6bd-c492-4328-93ea-3d036229301f"
WHERE "SKU"='KOCxxx' AND "狀態"='可用'
```

FB/IG 的類型優先序：**白底／設計卡／AI實景／實拍皆可用**（品牌帳號本來就是經營過的視覺），依內容類型挑：商品價值型優先白底或設計卡，教育型與見證品牌型優先實拍或 AI實景。

輸出 2–3 張候選（附圖名與類型）讓 Welson 挑，挑定再填 Notion。純教育文無主角商品時可略過。

**去重（2026-08-07 修訂，舊做法有洞，已作廢）**

素材庫已新增 **`最近使用日期`（date）** 欄位。挑圖前先排除近期用過的：

```sql
SELECT "圖名", "SKU", "類型", "場景", "圖片網址", "date:最近使用日期:start"
FROM "collection://a924b6bd-c492-4328-93ea-3d036229301f"
WHERE "SKU"='KOCxxx' AND "狀態"='可用'
  AND ("date:最近使用日期:start" IS NULL
       OR date("date:最近使用日期:start") < date('now','-30 day'))
```

**指派圖片後，必須回寫該素材列的 `最近使用日期`**（填該則貼文的發文日期；同一張被排在多天時填最晚那天）。不回寫，下一批就會重複踩。

> ⚠️ **舊做法「比對貼文 DB 的圖片網址字串」已作廢。** 同一張圖在三個渠道長得不一樣——Threads 是 `/v1784956081/KOC031_real_texture_01.jpg`，FB 是 `/c_limit,w_1200/f_auto,q_auto/KOC031_real_texture_01.jpg`——字串比對抓不到。要比對只能先抽出 public_id（去掉 `upload/` 後的所有 transform 片段與 `v<數字>/`、去掉副檔名）再比。2026-08 那批就是這樣漏掉的：`KOC073_ceo02_scene` 8/5 用過，8/19 又同時排進 Threads、FB、IG 三個渠道。

**跨渠道也要看。** FB/IG 與 Threads 是獨立內容線，但**素材是共用的**。同一張圖十天內出現在三個渠道，追蹤三個帳號的人會看到三次。查的時候不要只查自己那條線。

### Step B：依平台切尺寸（Cloudinary 動態裁切）

一張原圖可衍生所有比例——在 `upload/` 後面插參數即可，不必重複上傳。

| 平台／版位 | 參數 |
|---|---|
| FB 連結圖 | `c_fill,g_auto,w_1200,h_630` |
| FB 一般貼文 | `c_fill,g_auto,w_1200,h_1200` |
| IG 方形 | `c_fill,g_auto,w_1080,h_1080` |
| IG 直式 | `c_fill,g_auto,w_1080,h_1350` |
| IG 限動 | `c_fill,g_auto,w_1080,h_1920` |

範例：`https://res.cloudinary.com/s55rhpbr/image/upload/c_fill,g_auto,w_1080,h_1350/koc_xxx.jpg`

> `g_auto` 會自動抓主體置中，但**商品瓶身照仍需人眼確認沒被裁到標籤**。

> ⚠️ Threads 的配圖規則完全不同（只限寬不裁切、禁設計圖卡、半自動由人選），見 `kocskin-threads-writer`。

## 配圖託管（Cloudinary MCP，2026-07-22 起）

配圖上傳走 Cloudinary MCP（連接器名 `Cloudinary`，帳號 cloud name `s55rhpbr`）。工具 `mcp__Cloudinary__upload-asset`：

- **可靠上傳法**：`file` 帶「公開 HTTPS 網址」→ Cloudinary 抓圖入庫，任何大小都穩。
- **小圖**：`file` 可帶 base64 data URI（`data:image/...;base64,...`）。⚠️ 大圖（數十 KB 以上）**不要**用 inline base64——超長字串在工具層不穩、會 `Could not decode base64`；大圖一律走公開 URL。
- 上傳成功回傳 `secure_url`（`https://res.cloudinary.com/s55rhpbr/...`），把它填進 Notion 貼文列的「圖片網址」。
- 沙盒生成的卡片要上 Cloudinary：壓成精簡 JPEG 走 data URI（單張、體積小時可行），或先讓圖取得公開 URL 再讓 Cloudinary 以 URL 抓取。
- 不必再手動拖 Supabase；Supabase 公開 bucket 仍可作備援。
- 一律「先產文＋合規＋寫 Notion 待審」，配圖網址可同批填入；此步不改發佈關卡（送 Buffer 仍只由引擎在 Notion 核准後執行）。

## 觸發 vs 不觸發

**觸發**：KOCSKIN 品牌官方帳號的 FB／IG 貼文需求。

**不觸發**：
- **Threads／脆／@koc_skin → `kocskin-threads-writer`**
- LP 文案、廣告素材、Email、新聞稿 → 另行處理（直接請 Claude 撰寫並過 `kocskin-compliance-check`）
- Welson 個人 FB、露營瘋（瘋大叔）帳號 → 各自風格不同
- 純文案審查無生成需求 → `kocskin-compliance-check` 直接跑

## 依賴 skill

- `kocskin-product-lookup` — 指定商品時必呼叫
- `kocskin-compliance-check` — 產出後自動審查

兩者組成內容生產鏈：查 → 寫 → 審。

## 不要做的事

- ❌ 憑記憶寫商品資料（Step 1 用 product-lookup）
- ❌ 跳過合規審查（Step 3 必跑，且必須派獨立的一方，自己寫完自己審不算）
- ❌ 一貼二用（FB / IG 各自版型）
- ❌ **配圖有小燕入鏡卻用品牌口吻寫**（圖文人稱不一致，人白拍了）
- ❌ **用小燕的名義做效果見證**，或編造她的具體事件與引述句
- ❌ **第一人稱貼文沒註明「待本人確認」就寫進 Notion**
- ❌ 交出滿是 AI 痕跡的稿（破折號當連接詞、「不是⋯⋯是⋯⋯」對仗、段落長度整齊、收束總結句）——見 ceo-first-person.md 第四節十項自查
- ❌ **挑圖不查 `最近使用日期` 就指派**，或指派完不回寫該欄位（下一批必重複）
- ❌ **只查自己那條內容線的用圖**（FB/IG 與 Threads 內容線獨立，但素材共用，要跨渠道查）
- ❌ **用這支寫 Threads 貼文，或把 FB/IG 文案搬去 Threads**（兩條獨立內容線）
- ❌ 誤用此 skill 寫個人 FB 或露營瘋貼文
- ❌ 正式模式未經確認直接寫入 Notion
- ❌ **排程貼文直接呼叫 Buffer（create_post 等）**——送 Buffer 是引擎在 Notion 核准後的專責，AI 不碰。唯一例外是〈快線〉，且必須等 Welson 明確說「發」
- ❌ **把對話裡的「OK／定稿」當成 Notion 核准**——那只是同意文案內容，不是發佈授權
- ❌ 正式模式寫 Notion 時把狀態設成「核准」或勾「啟用自動發文」——一律留 `待審`／不勾，交給 Welson
- ❌ **文案內已放導購連結、又把同一條填進 Notion「導購連結」欄位**——引擎 v2 會在 FB 文末自動接一次，結果連結重複。規則：填了「導購連結」欄位，文案內就**不要**再放同一條連結（二擇一）。IG 不受影響（走 bio）

## 內部參考檔

- [references/ceo-first-person.md](references/ceo-first-person.md) — **執行長第一人稱模式與去 AI 味自查（配圖有小燕時必讀）**
- [references/content-types.md](references/content-types.md) — 4 種內容類型結構範本
- [references/platform-specs.md](references/platform-specs.md) — FB / IG 格式規範
- [references/voice-examples.md](references/voice-examples.md) — 好／壞語氣對照
- [references/weekly-rhythm.md](references/weekly-rhythm.md) — 週節奏（背景參考；主流程已不做比例追蹤）
